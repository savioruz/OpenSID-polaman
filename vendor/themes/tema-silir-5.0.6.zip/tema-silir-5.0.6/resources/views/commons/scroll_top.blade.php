<a href="#" class="fixed bottom-0 right-0 lg:mb-5 mb-16 mr-5 bg-tertiary text-white focus:outline-none ring-2 ring-tertiary ring-offset-2 flex items-center justify-center w-10 h-10 rounded-full scroll-top" id="scroll-to-top">
  <i class="ti ti-arrow-up text-lg"></i>
</a>