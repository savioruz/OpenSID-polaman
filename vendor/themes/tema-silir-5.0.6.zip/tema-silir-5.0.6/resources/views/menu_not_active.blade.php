@php $layout = 'full-content' @endphp
@extends('theme::layouts.master')

@section('content')
  @include('theme::commons.404')
@endsection