<p class="block text-xs lg:text-sm py-1" id="pagination-info"></p>
<div id="pagination-container"></div>

@push('scripts')
  <script src="{{ theme_asset('lib/js/pagination.min.js') }}"></script>
@endpush