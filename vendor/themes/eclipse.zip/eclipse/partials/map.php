<?php  if(!defined('BASEPATH')) exit('No direct script access allowed'); ?>

<section class="map">
	<?php $this->load->view($halaman_peta); ?>
</section>